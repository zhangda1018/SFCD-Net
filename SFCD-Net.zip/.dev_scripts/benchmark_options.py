third_part_libs = [
    'pip install mmengine',
    'pip install mmcv>=2.0.0',
    'pip install mmcls==1.0.0rc6',
    'pip install mmdet==3.0.0',
    'pip install -r requirements.txt',
    'pip install timm',
]

default_floating_range = 0.5
